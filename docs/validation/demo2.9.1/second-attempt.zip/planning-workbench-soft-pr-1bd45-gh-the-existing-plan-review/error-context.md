# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: planning-workbench.spec.ts >> soft preference is confirmed then compared and selected through the existing plan review
- Location: frontend/e2e/planning-workbench.spec.ts:24:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: '日程', exact: true })
    - locator resolved to <button type="button" aria-label="日程" data-page-id="calendar">…</button>
  - attempting click action
    - waiting for element to be visible, enabled and stable

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - complementary [ref=e4]:
    - generic [ref=e5]: 课间
    - navigation "主导航" [ref=e7]:
      - button "助手" [ref=e8] [cursor=pointer]
      - generic [ref=e13]:
        - button "今日" [ref=e14] [cursor=pointer]
        - button "日程" [ref=e19] [cursor=pointer]
        - button "任务" [ref=e23] [cursor=pointer]
        - button "课程资料" [ref=e28] [cursor=pointer]
    - generic [ref=e32]:
      - button "设置" [ref=e33] [cursor=pointer]
      - generic [ref=e36]: workbench-24b50a33-4575-491a-a152-2e05a773b68e@example.com
      - button "退出登录" [ref=e37] [cursor=pointer]
  - main [ref=e38]:
    - generic [ref=e39]:
      - generic [ref=e40]:
        - heading "今日" [level=1] [ref=e41]
        - generic [ref=e42]: 10月14日 · 周三
      - generic [ref=e43]:
        - button "待确认" [ref=e44] [cursor=pointer]
        - button "安排今天" [ref=e49] [cursor=pointer]
    - generic [ref=e50]:
      - region "接下来" [ref=e51]:
        - paragraph [ref=e52]: 暂无待办任务。
        - generic [ref=e53]:
          - generic [ref=e54]:
            - heading "其他待办0" [level=2] [ref=e55]
            - button "全部任务" [ref=e56] [cursor=pointer]
          - button "添加任务" [ref=e60] [cursor=pointer]
      - region "今日安排" [ref=e62]:
        - generic [ref=e63]:
          - heading "今日安排" [level=2] [ref=e64]
          - button "查看日程" [ref=e65] [cursor=pointer]
        - paragraph [ref=e66]: 今天暂无安排。
    - generic [ref=e67]:
      - button "执行与记录" [ref=e68] [cursor=pointer]
      - button "课后作业" [ref=e69] [cursor=pointer]
```

# Test source

```ts
  1  | import {expect,type Page} from '@playwright/test';
  2  | 
  3  | type Destination='courses'|'calendar'|'planning'|'rules'|'preferences'|'semester'|'reminders'|'models'|'data'|'goals'|'review'|'tasks'|'import'|'records'|'fixed';
  4  | // Exercise the same visible controls used in the App, including closing drawers.
  5  | export async function workspace(page:Page,destination:Destination){
  6  |   for(let i=0;i<6;i++){
  7  |     if(!await page.getByRole('dialog').count())break;
  8  |     await page.keyboard.press('Escape');
  9  |   }
  10 |   const settings=['preferences','semester','reminders','models','data'].includes(destination);
  11 |   if(destination==='records'){await page.getByRole('button',{name:'今日',exact:true}).click();await page.getByRole('button',{name:'执行与记录',exact:true}).click();return;}
  12 |   const task=['tasks','goals','review'].includes(destination);
> 13 |   await page.getByRole('button',{name:settings?'设置':task?'任务':'日程',exact:true}).click();
     |                                                                                 ^ Error: locator.click: Test timeout of 30000ms exceeded.
  14 |   const control:Partial<Record<Destination,string>>={courses:'课程',import:'导入课表',fixed:'固定事项',planning:'安排学习',rules:'课程规则',preferences:'学习偏好',semester:'课程与学期',reminders:'提醒与桌宠',models:'模型连接',data:'资料与备份',goals:'目标',review:'复盘'};
  15 |   if(!settings&&!task)await page.getByRole('button',{name:'全部',exact:true}).click();
  16 |   if(control[destination])await page.getByRole('button',{name:control[destination],exact:true}).click();
  17 |   if(destination==='review')await expect(page.getByRole('region',{name:'每周复盘',exact:true})).toBeVisible();
  18 | }
  19 | export async function inbox(page:Page,tab:'草稿'|'建议'|'时长'='草稿'){
  20 |   for(let i=0;i<6&&await page.getByRole('dialog').count();i++)await page.keyboard.press('Escape');
  21 |   await page.getByRole('button',{name:/^待确认(?: · \d+)?$/}).click();
  22 |   await page.getByRole('dialog',{name:'待确认',exact:true}).getByRole('button',{name:tab,exact:true}).click();
  23 | }
  24 | 
  25 | export async function negotiation(page:Page){await workspace(page,'review');await page.getByText('调整下一周安排',{exact:true}).click();}
  26 | 
```